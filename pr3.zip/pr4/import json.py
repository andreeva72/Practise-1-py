import json
import csv

country = {
    "название": "Россия",
    "столица": "Москва",
    "население": 146150000
}

with open("country.json", "w", encoding="utf-8") as f:
    json.dump(country, f, ensure_ascii=False, indent=2)

with open("country.json", "r", encoding="utf-8") as f:
    country = json.load(f)

country["язык"] = "русский"

with open("country.json", "w", encoding="utf-8") as f:
    json.dump(country, f, ensure_ascii=False, indent=2)


salary_by_position = {
    "Разработчик": 120000,
    "Менеджер": 100000,
    "Дизайнер": 90000
}

with open("csv.csv", "r", encoding="utf-8") as infile, \
     open("employees_with_salary.csv", "w", encoding="utf-8", newline="") as outfile:

    reader = csv.DictReader(infile)
    fieldnames = reader.fieldnames + ["Зарплата"]
    writer = csv.DictWriter(outfile, fieldnames=fieldnames)

    writer.writeheader()

    for row in reader:
        row["Зарплата"] = salary_by_position[row["Должность"]]
        writer.writerow(row)



age_sum = {}
count_by_city = {}
salary_sum = {}

with open("employees_with_salary.csv", "r", encoding="utf-8") as f:
    reader = csv.DictReader(f)

    for row in reader:
        city = row["Город"]
        position = row["Должность"]
        age = int(row["Возраст"])
        salary = int(row["Зарплата"])


        if city not in age_sum:
            age_sum[city] = 0
            count_by_city[city] = 0
        age_sum[city] += age
        count_by_city[city] += 1


        if position not in salary_sum:
            salary_sum[position] = 0
        salary_sum[position] += salary

avg_age = {}
for city in age_sum:
    avg_age[city] = round(age_sum[city] / count_by_city[city])

stats = {
    "средний возраст по городам": avg_age,
    "сумма зарплат по должностям": salary_sum,
    "количество по городам": count_by_city
}

with open("stats.json", "w", encoding="utf-8") as f:
    json.dump(stats, f, ensure_ascii=False, indent=2)