import random
import time

def slow_print (text, delay=0.05):
    for char in text:
        print(char, end="", flush=True)
        time.sleep(delay)
    print()

slow_print("Добро пожаловать в игру 'Детективное расследование'!")
print("Ты — детектив, расследующий загадочную кражу из музея.")
print("Твоя задача — собрать улики, допросить подозреваемых и найти преступника!\n")

time.sleep(2)


suspects = ["директор", "охранник", "гид", "уборщица", "реставратор"]
culprit = random.choice(suspects)

found_clues = []
evidence_points = 0

print("=== УРОВЕНЬ 1: ОСМОТР МЕСТА ПРЕСТУПЛЕНИЯ ===")
slow_print("Ты входишь в музей. Витрина, где хранился бриллиант, пуста.")
slow_print("Выбери, с чего начнёшь осмотр.\n")

searched_rooms = []

while True:
    print("Доступные места осмотра:")
    print("1 — Витрина")
    print("2 — Кабинет директора")
    print("3 — Комната охраны")
    print("4 — Коридор")
    print("5 — Завершить осмотр")
    choice = input("Твой выбор: ")

    if choice == "1" and "витрина" not in searched_rooms:
        print("\nТы осматриваешь витрину...")
        print("На стекле — аккуратный разрез, как будто кто-то использовал специальный инструмент.\n")
        time.sleep(1)
        found_clues.append("след от инструмента")
        evidence_points += 1
        searched_rooms.append("витрина")
    elif choice == "2" and "кабинет директора" not in searched_rooms:
        print("\nТы осматриваешь кабинет директора...")
        print("В кабинете директора беспорядок. На полу валяется ключ-карта и квитанция из ломбарда.\n")
        time.sleep(1)
        found_clues.extend(["ключ-карта", "квитанция"])
        evidence_points += 2
        searched_rooms.append("кабинет директора")
    elif choice == "3" and "комната охраны" not in searched_rooms:
        print("\nТы осматриваешь комнату охраны...")
        print("Ты находишь журнал дежурств. Камеры были выключены с 23:00 до 23:10 — именно во время кражи.\n")
        time.sleep(1)
        found_clues.append("журнал дежурств")
        evidence_points += 1
        searched_rooms.append("комната охраны")
    elif choice == "4" and "коридор" not in searched_rooms:
        print("\nТы осматриваешь коридор...")
        print("На полу грязные следы, а рядом кусочек ткани от формы.\n")
        time.sleep(1)
        found_clues.append("кусок ткани")
        evidence_points += 1
        searched_rooms.append("коридор")
    elif choice == "5":
        if len(searched_rooms) == 0:
            print("Ты пока ничего не осмотрел. Начни хотя бы с одного места.\n")
            time.sleep(1)
        else:
            print("\nТы завершил осмотр музея. Пора переходить к анализу улик.\n")
            break
    else:
        print("Это место уже осмотрено или неправильный выбор.\n")
        time.sleep(1)

time.sleep(2)

print("=== УРОВЕНЬ 2: АНАЛИЗ УЛИК ===")
slow_print("Теперь нужно понять, кому принадлежат найденные предметы.\n")

time.sleep(2)

for clue in found_clues:
    print(f"- Улика: {clue}")
    time.sleep(2)
    if clue == "след от инструмента":
        print("→ Похоже, преступник использовал профессиональные инструменты. Возможно, реставратор.")
        evidence_points += 1
    elif clue == "ключ-карта":
        print("→ Доступ к музею ночью есть только у директора и охраны.")
        evidence_points += 2
    elif clue == "журнал дежурств":
        print("→ Камеры отключались вручную. Охранник может быть причастен.")
        evidence_points += 2
    elif clue == "кусок ткани":
        print("→ Ткань напоминает униформу уборщицы.")
        evidence_points += 1
    elif clue == "квитанция":
        print("→ Кто-то закладывал дорогие украшения в ломбарде... подозрительно.")
        evidence_points += 2
    else:
        print("Улики не найдены.")

time.sleep(2)

slow_print("\nТы закончил анализ. Теперь можно задать уточняющие вопросы свидетелям.\n")

time.sleep(2)

print("=== УРОВЕНЬ 3: ДОПРОС ПОДОЗРЕВАЕМЫХ ===")
slow_print("Ты можешь допросить только трёх человек! Задавай им вопросы.\n")

time.sleep(0.5)
for i in range(3):
    print("Подозреваемые:", ", ".join(suspects))
    person = input("Кого допросим? ").lower()

    if person not in suspects:
        print("Такого человека нет.")
        continue

    print(f"\nТы допросил {person}.")
    time.sleep(1)
    slow_print("Задай вопрос (например: 'Где вы были ночью?' или 'Чем вы занимались этой ночью?'):")
    question = input("Вопрос: ")
    time.sleep(1)

    print(f"{person.capitalize()} отвечает...")
    time.sleep(2)

    if person == culprit:
        response = random.choice([
            "Ну... я не обязан на это отвечать.",
            "Я был дома... один.",
            "Это всё совпадение!",
            "Вы меня подозреваете зря!"
        ])
    else:
        response = random.choice([
            "Я ничего не знаю.",
            "Был на рабочем месте, можете проверить.",
            "Слышал, как сигнализация сработала.",
            "Всё это ужасно!"
        ])
    print(response)

    if person == culprit:
        print("Ты чувствуешь, что он нервничает... что-то здесь не так.")
        evidence_points += 3
    else:
        print("Похоже, он говорит правду.")
        evidence_points += 1

    cont = input("Продолжить допрос? (да/нет): ").lower()
    if cont == "нет":
        break


print("\n=== УРОВЕНЬ 4: ВОЗВРАТ НА МЕСТО ПРЕСТУПЛЕНИЯ ===")
slow_print("Ты решаешь проверить музей ещё раз — вдруг осталась незамеченная улика.\n")

time.sleep(2)

while True:
    print("Где искать?")
    print("1 — Под витриной")
    print("2 — У задней двери")
    print("3 — В подсобке уборщицы")
    print("4 — Завершить поиск")

    extra_choice = input("Твой выбор: ")

    if extra_choice == "1":
        print("\nПод витриной ты находишь крошечный кусочек стекла с отпечатком пальца.")
        found_clues.append("отпечаток пальца")
        evidence_points += 3
    elif extra_choice == "2":
        print("\nУ двери найден ботинок с грязью — но не музейной.")
        found_clues.append("ботинок")
        evidence_points += 2
    elif extra_choice == "3":
        print("\nВ подсобке стоит ведро, а внутри — тряпка с песком от витрины.")
        found_clues.append("тряпка с песком")
        evidence_points += 3
    elif extra_choice == "4":
        print("Ты завершил дополнительный поиск.")
        break
    else:
        print("Нет такого варианта.")
    time.sleep(1)
    cont = input("Искать дальше? (да/нет): ").lower()
    if cont == "нет":
        break

time.sleep(2)

print("\n=== УРОВЕНЬ 5: СОПОСТАВЛЕНИЕ ФАКТОВ ===")
slow_print("Ты собираешь все улики воедино.\n")

time.sleep(1)

for clue in found_clues:
    if clue == "отпечаток пальца" and culprit == "директор":
        print("Отпечаток совпадает с директором!")
        evidence_points += 5
    elif clue == "ботинок" and culprit == "охранник":
        print("Размер ботинка совпадает с охранником.")
        evidence_points += 3
    elif clue == "тряпка с песком" and culprit == "уборщица":
        print("Песок с витрины — уборщица явно здесь была.")
        evidence_points += 4
    elif clue == "след от инструмента" and culprit == "реставратор":
        print("След совпадает с инструментом реставратора!")
        evidence_points += 4

time.sleep(1)
slow_print("\nТеперь у тебя достаточно данных, чтобы обвинить преступника.\n")
time.sleep(1)

print("=== УРОВЕНЬ 6: ОБВИНЕНИЕ ===")
print("Подозреваемые:", ", ".join(suspects))
guess = input("Кого ты считаешь виновным? ").lower()

time.sleep(1)

print("\n=== РЕЗУЛЬТАТ ===")
if guess == culprit:
    slow_print(f"Верно! Преступником оказался {culprit}!")
    if evidence_points > 10:
        print("Ты собрал все улики и полностью доказал его вину. Отличная работа!")
    else:
        print("Ты раскрыл дело, но некоторых доказательств не хватало.")
else:
    slow_print(f"Ошибка. Настоящий преступник — {culprit}.")
    if evidence_points > 10:
        print("Ты почти всё понял, но ошибся с выбором.")
    else:
        print("Твоё расследование провалилось. Попробуй снова!")
time.sleep(2)
print("\n=== ИТОГ РАССЛЕДОВАНИЯ ===")
print(f"Собрано улик: {len(found_clues)}")
print(f"Очки доказательств: {evidence_points}")
print("Все улики:")
for clue in found_clues:
    print("-", clue)

slow_print("\nСпасибо за игру, детектив!")
slow_print("Удачи в дальнейших расследованиях!")